module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://127.0.0.1:27017/nucampsite',
    'facebook': {
        clientId: 'YOUR APP ID HERE',
        clientSecret: 'YOUR APP SECRET HERE'
    }
}